export default {
  'GET /api/users': {
    code: 0,
    data: [{ title: 'mock A' }, { title: 'mock B' }, { title: 'mock C' }],
  },
};
