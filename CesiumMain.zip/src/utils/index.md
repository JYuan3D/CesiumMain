## utils

Demo:


```js

```

